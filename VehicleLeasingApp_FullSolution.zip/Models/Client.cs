
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace VehicleLeasingApp.Models
{
    public class Client
    {
        public int ClientId { get; set; }

        [Required]
        public string CompanyName { get; set; }

        public string ContactPerson { get; set; }

        public virtual ICollection<Vehicle> Vehicles { get; set; }
    }
}
