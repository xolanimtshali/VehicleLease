
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VehicleLeasingApp.Models
{
    public class Vehicle
    {
        public int VehicleId { get; set; }

        [Required]
        public string Manufacturer { get; set; }

        public string Model { get; set; }

        public int Year { get; set; }

        public int SupplierId { get; set; }
        public virtual Supplier Supplier { get; set; }

        public int BranchId { get; set; }
        public virtual Branch Branch { get; set; }

        public int ClientId { get; set; }
        public virtual Client Client { get; set; }

        public int? DriverId { get; set; }
        public virtual Driver Driver { get; set; }
    }
}
