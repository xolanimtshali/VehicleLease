
using System.ComponentModel.DataAnnotations;

namespace VehicleLeasingApp.Models
{
    public class Driver
    {
        public int DriverId { get; set; }

        [Required]
        public string FullName { get; set; }

        public string LicenseNumber { get; set; }

        public virtual Vehicle Vehicle { get; set; }
    }
}
