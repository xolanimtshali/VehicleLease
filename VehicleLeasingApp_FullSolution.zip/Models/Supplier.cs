
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace VehicleLeasingApp.Models
{
    public class Supplier
    {
        public int SupplierId { get; set; }

        [Required]
        public string Name { get; set; }

        public string Location { get; set; }

        public virtual ICollection<Vehicle> Vehicles { get; set; }
    }
}
