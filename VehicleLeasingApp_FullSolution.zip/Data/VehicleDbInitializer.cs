
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using VehicleLeasingApp.Models;

namespace VehicleLeasingApp.Data
{
    public class VehicleDbInitializer : DropCreateDatabaseIfModelChanges<ApplicationDbContext>
    {
        protected override void Seed(ApplicationDbContext context)
        {
            var suppliers = new List<Supplier>
            {
                new Supplier { Name = "AutoWorld Ltd" },
                new Supplier { Name = "Prime Motors" },
                new Supplier { Name = "Global Vehicles" }
            };
            suppliers.ForEach(s => context.Suppliers.Add(s));

            var branches = new List<Branch>
            {
                new Branch { Name = "Johannesburg", Location = "JHB Central" },
                new Branch { Name = "Cape Town", Location = "CT Waterfront" }
            };
            branches.ForEach(b => context.Branches.Add(b));

            var clients = new List<Client>
            {
                new Client { Name = "TransAfrica Logistics", ContactEmail = "contact@transafrica.com" },
                new Client { Name = "EcoRide SA", ContactEmail = "info@ecoride.co.za" }
            };
            clients.ForEach(c => context.Clients.Add(c));

            var drivers = new List<Driver>
            {
                new Driver { Name = "John Mokoena", LicenseNumber = "JHB123456" },
                new Driver { Name = "Lerato Dube", LicenseNumber = "CT654321" }
            };
            drivers.ForEach(d => context.Drivers.Add(d));

            context.SaveChanges();

            var vehicles = new List<Vehicle>
            {
                new Vehicle {
                    Model = "Hilux",
                    Manufacturer = "Toyota",
                    SupplierId = suppliers[0].SupplierId,
                    BranchId = branches[0].BranchId,
                    ClientId = clients[0].ClientId,
                    DriverId = drivers[0].DriverId
                },
                new Vehicle {
                    Model = "Ranger",
                    Manufacturer = "Ford",
                    SupplierId = suppliers[1].SupplierId,
                    BranchId = branches[1].BranchId,
                    ClientId = clients[1].ClientId,
                    DriverId = drivers[1].DriverId
                },
                new Vehicle {
                    Model = "Sprinter",
                    Manufacturer = "Mercedes-Benz",
                    SupplierId = suppliers[2].SupplierId,
                    BranchId = branches[0].BranchId,
                    ClientId = clients[0].ClientId,
                    DriverId = drivers[1].DriverId
                }
            };
            vehicles.ForEach(v => context.Vehicles.Add(v));

            context.SaveChanges();
        }
    }
}
